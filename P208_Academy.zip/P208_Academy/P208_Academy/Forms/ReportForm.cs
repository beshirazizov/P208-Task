﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using P208_Academy.Data;

namespace P208_Academy.Forms
{
    public partial class ReportForm : Form
    {
        public ReportForm()
        {
            InitializeComponent();
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
            //fill data grid view with Students list
            dgwStudents.DataSource = StudentList.Students;

            //fill Combobox of Groups in order to show Groups
            List<GroupComboItem> comboSource = new List<GroupComboItem>();

            foreach (Group group in GroupList.Groups)
            {
                comboSource.Add(new GroupComboItem
                {
                    Text = group.GroupName,
                    Value = group.GroupID
                });
            }

            cmbGroups.Items.Add("All");
            cmbGroups.Items.AddRange(comboSource.ToArray());
            
        }

        private void cmbGroups_SelectedIndexChanged(object sender, EventArgs e)
        {
            string groupName = cmbGroups.Text;

            int index = dgwStudents.Columns["Group"].Index;

            foreach (DataGridViewRow item in dgwStudents.Rows)
            {
                if (item.Cells[index].Value.ToString() == groupName)
                {
                    item.DefaultCellStyle.BackColor = Color.Green;
                    //item.DefaultCellStyle.Font = new System.Drawing.Font("Showcard", 24.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
                else
                {
                    item.DefaultCellStyle.BackColor = Color.White;
                    //item.DefaultCellStyle.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }

        private void dgwStudents_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            string studentId= dgwStudents.SelectedRows[0].Cells[0].Value.ToString();

            Student studentToBeEdited = StudentList.GetStudentsById(studentId);

            EditPanel.Visible = true;

            tbName.Text = studentToBeEdited.Firstname;
            tbSurname.Text = studentToBeEdited.Lastname;
            tbEmail.Text = studentToBeEdited.Email;
            lblID.Text = studentToBeEdited.StudentID;
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            //LINQ
            string studentId = lblID.Text;
            StudentList.Students.First(student => student.StudentID == studentId).Firstname = tbName.Text;
            StudentList.Students.First(student => student.StudentID == studentId).Lastname = tbSurname.Text;
            StudentList.Students.First(student => student.StudentID == studentId).Email = tbEmail.Text;

            EditPanel.Visible = false;

            dgwStudents.DataSource = null;
            dgwStudents.DataSource = StudentList.Students;
        }
    }
}
