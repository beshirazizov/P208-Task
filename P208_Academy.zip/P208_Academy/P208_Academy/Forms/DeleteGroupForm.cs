﻿using P208_Academy.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P208_Academy.Forms
{
    public partial class DeleteGroupForm : Form
    {
        public DeleteGroupForm()
        {
            InitializeComponent();
        }

        private void DeleteGroupForm_Load(object sender, EventArgs e)
        {
            updateCombo();
        }

        private void btnDelGroup_Click(object sender, EventArgs e)
        {
            DialogResult messageboxResult = MessageBox.Show("Eminsiz? Qrupda olan butun telebeler silinecek!","Are you sure?",MessageBoxButtons.YesNo);

            if (messageboxResult == DialogResult.Yes)
            {
                string groupId = ((GroupComboItem)cmbDel.SelectedItem).Value;

                Group GroupToBeDeleted = GroupList.GetGroupById(groupId);

                GroupList.Groups.Remove(GroupToBeDeleted);


                List<Student> studentsToBeDeleted = StudentList.GetStudentsByGroup(GroupToBeDeleted);

                foreach (Student item in studentsToBeDeleted)
                {
                    StudentList.Students.Remove(item);
                }

                updateCombo();

            }
            else
            {
                MessageBox.Show("Siryoznu ol biraz!");
            }

        }
        private void updateCombo()
        {
            List<GroupComboItem> comboSource = new List<GroupComboItem>();

            foreach (Group group in GroupList.Groups)
            {
                comboSource.Add(new GroupComboItem
                {
                    Text = group.GroupName,
                    Value = group.GroupID
                });
            }

            cmbDel.DataSource = comboSource;
        }
    }
}
