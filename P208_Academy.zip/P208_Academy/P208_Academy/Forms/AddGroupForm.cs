﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using P208_Academy.Data;

namespace P208_Academy.Forms
{
    public partial class AddGroupForm : Form
    {
        public AddGroupForm()
        {
            InitializeComponent();
        }

        private void btnAddGroup_Click(object sender, EventArgs e)
        {
            string groupName = txtGroupname.Text.Trim();

            if (string.IsNullOrEmpty(groupName)){
                MessageBox.Show("Group name is not valid", "Failed!",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            if (GroupList.ContainsGroupName(groupName))
            {
                MessageBox.Show("Group name is duplicate", "Failed!",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            //user entered valid group name and is not duplicate
            //so add new group to Grouplist
            GroupList.Add(new Group(groupName));

            txtGroupname.Text = "";

            MessageBox.Show("New Group was successfully added", "Success!",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
