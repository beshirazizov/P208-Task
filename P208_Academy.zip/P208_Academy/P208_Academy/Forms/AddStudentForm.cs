﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using P208_Academy.Data;

namespace P208_Academy
{
    public partial class AddStudentForm : Form
    {
        public AddStudentForm()
        {
            InitializeComponent();
        }

        private void AddStudentForm_Load(object sender, EventArgs e)
        {
            //GroupList groupList = new GroupList();

            List<GroupComboItem> comboSource = new List<GroupComboItem>();

            foreach (Group group in GroupList.Groups)
            {
                comboSource.Add(new GroupComboItem
                {
                    Text = group.GroupName,
                    Value = group.GroupID
                });
            }

            cmbGroups.DataSource = comboSource;
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            string firstname = txtFirstname.Text.Trim();
            string lastname = txtLastname.Text.Trim();
            string email = txtEmail.Text.Trim();
            string groupId = ((GroupComboItem)cmbGroups.SelectedItem).Value;

            Group selectedGroup = GroupList.GetGroupById(groupId);

            if (selectedGroup == null)
            {
                MessageBox.Show("Group doesn't exist");
                return;
            }

            if (string.IsNullOrEmpty(firstname) ||
                string.IsNullOrEmpty(lastname) ||
                !email.Contains("@"))
            {
                MessageBox.Show("Student credentials are not valid", "Failed!",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            if (StudentList.ContainsEmail(email))
            {
                MessageBox.Show("Student email is duplicate", "Failed!",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            //Student is OK!

            StudentList.Add(new Student
            {
                Firstname = firstname,
                Lastname = lastname,
                Email = email,
                Group = selectedGroup
            });

            MessageBox.Show($"Student {firstname} {lastname} was successfully added", "Success!",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

            Close();
        }

    }
}
