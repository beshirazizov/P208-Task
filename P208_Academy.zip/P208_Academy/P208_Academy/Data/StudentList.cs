﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P208_Academy.Data
{
    public static class StudentList
    {
        public static List<Student> Students { get; private set; }

        static StudentList()
        {
            Students = new List<Student>();

            //only for demo purposes
            Students.Add(new Student
            {
                Firstname = "Aqil",
                Lastname = "Atakisiyev",
                Email = "aqil@code.edu.az",
                Group = GroupList.GetGroupById("00001")
            });
            Students.Add(new Student
            {
                Firstname = "Rufet",
                Lastname = "Eliyev",
                Email = "rufetza@code.edu.az",
                Group = GroupList.GetGroupById("00002")
            });
            Students.Add(new Student
            {
                Firstname = "Samir",
                Lastname = "Beydullayev",
                Email = "samirba@code.edu.az",
                Group = GroupList.GetGroupById("00001")
            });
            Students.Add(new Student
            {
                Firstname = "Resul",
                Lastname = "Agarzayev",
                Email = "resul@code.edu.az",
                Group = GroupList.GetGroupById("00002")
            });
            Students.Add(new Student
            {
                Firstname = "Ibrahim",
                Lastname = "Memmedov",
                Email = "ibo@code.edu.az",
                Group = GroupList.GetGroupById("00001")
            });

        }

        public static void Add(Student student)
        {
            Students.Add(student);
        }

        public static bool ContainsEmail(string email)
        {
            foreach (var item in Students)
            {
                if(item.Email == email)
                {
                    return true;
                }
            }

            return false;
        }


        public static List<Student> GetStudentsByGroup(Group group)
        {
            List<Student> studentsInGroup = new List<Student>();
            foreach (var student in Students)
            {
                if (student.Group == group)
                {
                    studentsInGroup.Add(student);
                }
            }
            return studentsInGroup;
        }

        public static Student GetStudentsById(string Id)
        {
            foreach (var student in Students)
            {
                if (student.StudentID == Id)
                {
                    return student;
                }
            }
            return null;
        }
    }
}
