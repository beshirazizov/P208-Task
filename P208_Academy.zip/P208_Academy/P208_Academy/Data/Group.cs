﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P208_Academy.Data
{
    public class Group
    {
        public string GroupID { get; private set; }
        public string GroupName { get; set; }

        private static int groupIDCounter = 1;

        public Group(string groupName)
        {
            GroupName = groupName;
            GroupID = new string('0', 5 - groupIDCounter.ToString().Length) + groupIDCounter++;
        }

        public override string ToString() => GroupName;

    }
}
