﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P208_Academy.Data
{
    public static class GroupList
    {
        public static List<Group> Groups { get; private set; }

        //static constructors works only once
        static GroupList()
        {
            Groups = new List<Group>();

            Groups.Add(new Group("P208"));
            Groups.Add(new Group("P209"));
            Groups.Add(new Group("V403"));
            Groups.Add(new Group("V305"));
        }

        public static void Add(Group group)
        {
            Groups.Add(group);
        }

        public static Group GetGroupById(string groupID)
        {
            //possible with LINQ in the future
            foreach (Group group in Groups)
            {
                if(group.GroupID == groupID)
                {
                    return group;
                }
            }

            return null;
        }

        public static bool ContainsGroupName(string groupName)
        {
            foreach (Group group in GroupList.Groups)
            {
                if (group.GroupName.ToUpper() == groupName.ToUpper())
                {
                    return true;
                }
            }

            return false;
        }
    }
}
